// Add tilt effect to cards
VanillaTilt.init(document.querySelectorAll(".card"), {
    max: 15, // Maximum tilt rotation (degrees)
    speed: 400, // Speed of the tilt effect
    glare: true, // Enable glare effect
    "max-glare": 0.2, // Maximum glare opacity
});

// Add hover effect to navigation links
const navLinks = document.querySelectorAll(".navbar-menu a");
const navIndicator = document.querySelector(".nav-indicator");

navLinks.forEach((link) => {
    link.addEventListener("mouseenter", () => {
        const linkWidth = link.offsetWidth;
        const linkLeft = link.offsetLeft;
        navIndicator.style.width = `${linkWidth}px`;
        navIndicator.style.left = `${linkLeft}px`;
    });

    link.addEventListener("mouseleave", () => {
        const activeLink = document.querySelector(".navbar-menu a.active");
        if (activeLink) {
            const activeWidth = activeLink.offsetWidth;
            const activeLeft = activeLink.offsetLeft;
            navIndicator.style.width = `${activeWidth}px`;
            navIndicator.style.left = `${activeLeft}px`;
        } else {
            navIndicator.style.width = "0";
        }
    });
});


